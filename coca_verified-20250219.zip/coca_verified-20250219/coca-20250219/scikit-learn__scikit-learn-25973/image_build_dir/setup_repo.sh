#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/scikit-learn/scikit-learn /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard 10dbc142bd17ccf7bd38eec2ac04b52ce0d1009e
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
