#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/astropy/astropy /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard 3cedd79e6c121910220f8e6df77c54a0b344ea94
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
python -m pip install -e .[test] --verbose
