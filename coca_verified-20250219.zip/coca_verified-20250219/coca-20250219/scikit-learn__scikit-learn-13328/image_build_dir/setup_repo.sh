#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/scikit-learn/scikit-learn /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard 37b0e66c871e8fb032a9c7086b2a1d5419838154
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
