#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/sphinx-doc/sphinx /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard f35d2a6cc726f97d0e859ca7a0e1729f7da8a6c8
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
sed -i 's/pytest/pytest -rA/' tox.ini
python -m pip install -e .[test]
