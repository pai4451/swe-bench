#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/astropy/astropy /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard 1a4462d72eb03f30dc83a879b1dd57aac8b2c18b
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
sed -i 's/requires = \["setuptools",/requires = \["setuptools==68.0.0",/' pyproject.toml
python -m pip install -e .[test] --verbose
