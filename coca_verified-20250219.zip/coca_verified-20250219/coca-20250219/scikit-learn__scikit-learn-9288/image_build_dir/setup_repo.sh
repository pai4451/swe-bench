#!/bin/bash
set -euxo pipefail
git clone -o origin https://github.com/scikit-learn/scikit-learn /testbed
chmod -R 777 /testbed
cd /testbed
git reset --hard 3eacf948e0f95ef957862568d87ce082f378e186
git remote remove origin
source /opt/miniconda3/bin/activate
conda activate testbed
echo "Current environment: $CONDA_DEFAULT_ENV"
python -m pip install -v --no-use-pep517 --no-build-isolation -e .
